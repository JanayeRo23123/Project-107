//here goes the imports
import "./navbar.css";

//here goes the logic --> the fuction has to begin with a capital letter when inside a component
function Navbar(){
    
    return (
        <h1>Navbar Goes Here</h1>
    );
}

//here goes the exports

export default Navbar;

//create a footer for your page