import "./products.css";
import QuantityPicker from "./quantityPicker";
import { useEffect } from "react";

function Products(props){

    useEffect(function(){

        console.log("Hello I am a product");

    },[]);
    return (
        <div className="products">
            <img src={'/images/'+ props.data.image} alt=""></img>
            <h5>{props.data.title}</h5>

            <div className="price">
                <label className="price">${props.data.price.toFixed(2)}</label>
            </div>

            <QuantityPicker></QuantityPicker>
        </div>

    );
}
export default Products;
