import "./footer.css";

function Footer(){

    return(
        <p>HoneyCo. Wholistics</p>
    );


}

export default Footer;
